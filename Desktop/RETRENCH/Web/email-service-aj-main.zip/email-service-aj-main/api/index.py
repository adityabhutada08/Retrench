import os
import smtplib
from email.message import EmailMessage

from dotenv import load_dotenv
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
load_dotenv()

EMAIL_USERNAME = os.getenv("EMAIL_USERNAME")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")
USER_SUBJECT = "ENQUIRY"
CUSTOMER_SUBJECT = "We have received your query"


def send_email(smtp, from_email, to_email, subject, body):
    msg = EmailMessage()
    msg["From"] = from_email
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.set_content(body)
    try:
        smtp.send_message(msg)
        return jsonify({"message": "Email sent successfully!"}), 200
    except Exception as e:
        return jsonify({"message": f"Failed to send email: {str(e)}"}), 500


@app.route("/")
def index():
    return "Hello"


@app.route("/send_email", methods=["POST"])
def send_email_route():
    if request.method == "POST":
        enquires_name = request.form.get("enquires_name")
        enquires_email = request.form.get("enquires_email")
        enquires_mobile = request.form.get("enquires_mobile")
        enquires_query = request.form.get("enquires_query")

        body_user = f"""
        Name : {enquires_name}
        Email : {enquires_email}
        Mobile : {enquires_mobile}
        Query : {enquires_query}
        """

        body_customer = """
        Thank you for contacting us. We will get back to you shortly.

        Kind Regards,
        AJ Energy Solutions
        +91 9209923030

        Shop No. 10, Bhale Complex, Dalalwadi, New Gulmandi Road, Chh SambhajiNagar - 431001
        """

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(EMAIL_USERNAME, EMAIL_PASSWORD)
            user_email_result = send_email(
                smtp, EMAIL_USERNAME, EMAIL_USERNAME, USER_SUBJECT, body_user
            )
            # customer_email_result = send_email(
            #     smtp, EMAIL_USERNAME, enquires_email, CUSTOMER_SUBJECT, body_customer
            # )

            if user_email_result[1] == 200:
                return user_email_result


if __name__ == "__main__":
    app.run(debug=True)
